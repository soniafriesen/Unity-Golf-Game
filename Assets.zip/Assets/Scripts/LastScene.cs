﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LastScene : MonoBehaviour
{
    public Rigidbody RB;
    public float Force = 200;
    public Transform PlayerTransform;
    public AudioSource flagTouch;
    public AudioSource characterMoveMusic;
    private AudioSource[] sounds;
    private bool scoreCounter = false;
    public Text scoreText;
    private int score;
    public Text powerText;
    private int power;
    void Start()
    {
        sounds = GetComponents<AudioSource>();
        characterMoveMusic = sounds[0];
        flagTouch = sounds[1];

    }

    void Update()
    {
        scoreCounter = true;
        //Calculate the direction to the ball
        Vector3 playerToGolfballVector = transform.position - PlayerTransform.position;
        playerToGolfballVector.y = 0.0f;
        playerToGolfballVector.Normalize();

        if (Input.GetKey(KeyCode.Space))
        {
            Force += 10;
            ++power;
            powerText.text = "Power: " + power;
        }

        if (Input.GetKeyUp(KeyCode.Space))
        {
            RB.AddForce(playerToGolfballVector * Force);
            characterMoveMusic.Play();
            Force = 200;
            if (scoreCounter == true)
            {
                ++score;
                power = 0;
                scoreText.text = "SCORE: " + score;
                powerText.text = "Power: " + power;
            }
        }
        scoreCounter = false;

    }
    //get our collisions and tirggers

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.name == "wall")
        {
            RB.velocity = Vector3.down;
            RB.velocity = Vector3.zero;
        }
    }
    private void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.name == "Flag")
        {
            flagTouch.Play();            
            SceneManager.LoadScene(0);
            Debug.Log("Hit!");
        }
    }
}
