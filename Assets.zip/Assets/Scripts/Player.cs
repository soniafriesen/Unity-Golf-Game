﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public bool VerticalInversion = false;
    public float MovementSpeed = 3.0f;
    private Vector2 mouseAbsolute;
    public float Sensitivity = 2.0f;


    // Start is called before the first frame update
    void Start()
    {
        //Turn off the cursor so we don't see it in the game window
        Cursor.visible = false;

        //Lock the cursor to the window so we don't 
        Cursor.lockState = CursorLockMode.Confined;
    }

    // Update is called once per frame
    void Update()
    {
        //Get the "forward" based on which way we're facing
        Vector3 Forward = transform.forward;

        Forward.y = 0.0f;   //Remove the y height so that we're level with the ground
        Forward.Normalize();    //Re normalize the vector so it has the length of 1

        //Get the forward / back movement based on the input managers axes
        Forward = Forward * Input.GetAxis("Vertical") * MovementSpeed * Time.deltaTime;

        //Get the right / left movement
        Vector3 Right = transform.right * Input.GetAxis("Horizontal") * MovementSpeed * Time.deltaTime;

        //Apply the movement to the camera
        transform.position += Forward + Right;

        //Get the mouse delta (change since last frame)
        Vector2 mouseDelta = new Vector2(Input.GetAxisRaw("Mouse X"), Input.GetAxisRaw("Mouse Y"));

        //Apply mouse sensitivity
        mouseDelta *= Sensitivity;

        //Add on the mouse delta to the current mousePosition of last frame
        mouseAbsolute += mouseDelta;

        //Lock the camera from moving to far up or down
        mouseAbsolute.y = Mathf.Clamp(mouseAbsolute.y, -89.9f, 89.9f);

        //Add the ability to inverse controls
        int inverse = -1;
        if (VerticalInversion)
        {
            inverse = 1;
        }

        //Apply the up and down rotation of the camera
        transform.localRotation = Quaternion.AngleAxis(inverse * mouseAbsolute.y, Vector3.right);

        //Calculate the y rotation of the camera
        Quaternion yRotation = Quaternion.AngleAxis(mouseAbsolute.x, transform.InverseTransformDirection(Vector3.up));
        transform.localRotation *= yRotation;

        //RaycastHit hit;
        //if (Physics.Raycast(transform.position, Vector3.down, out hit))
        //{
        //    Debug.Log("HIT!");
        //    Debug.DrawRay(transform.position, Vector3.down, Color.yellow);

        //    transform.position = hit.point + new Vector3(0.0f, 3.0f, 0.0f);
        //}
    }
}

