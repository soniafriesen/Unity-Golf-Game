﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arrow : MonoBehaviour
{
    public Transform GolfBallTransform;
    public Transform PlayerTransform;
    public MeshRenderer ArrowRenderer;
    public Rigidbody GolfBallRB;

    // Update is called once per frame
    void Update()
    {
       //Create a vector the represents a line from player to ball
        Vector3 playerToGolfballVector = GolfBallTransform.position - PlayerTransform.position;

        //The the vectors y to 0 as we want the arrow to remain flat with the ground
        playerToGolfballVector.y = 0.0f;

        //Set the length (magnitude) of the vector to 1
        playerToGolfballVector.Normalize();

        //Multiple the vector by the distance away we want the arrow to be from the ball
        //playerToGolfballVector *= 2.0f;

        //Finally set the position of the arrow
        transform.position = GolfBallTransform.position + playerToGolfballVector;

        //Calculate the rotation of the arrow based of the vector we just caculated
        float angle = Mathf.Atan2(playerToGolfballVector.z, playerToGolfballVector.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.AngleAxis(-angle, Vector3.up);
        transform.Rotate(new Vector3(90.0f, 0.0f, 0.0f));



        //Alternative check
        //Is the golf balls current position the same as the last frame?
        //If no it's moving, if yes it's stopped

        if (GolfBallRB.IsSleeping())
        {
            ArrowRenderer.enabled = true;
        }
        else
        {
            ArrowRenderer.enabled = false;
        }
    }
}
